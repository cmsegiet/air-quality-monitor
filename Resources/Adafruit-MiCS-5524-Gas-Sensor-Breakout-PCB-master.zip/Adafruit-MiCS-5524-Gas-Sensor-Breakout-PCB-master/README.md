# Adafruit-MiCS-5524-Gas-Sensor-Breakout-PCB
PCB files for the Adafruit MiCS-5524 Gas Sensor Breakout

Format is EagleCAD schematic and board layout

For more details, check out the product page at

    * https://www.adafruit.com/product/3199

Adafruit invests time and resources providing this open source design, please support Adafruit and open-source hardware by purchasing products from Adafruit!

Designed by Limor Fried/Ladyada for Adafruit Industries.
Creative Commons Attribution/Share-Alike, all text above must be included in any redistribution